import React from "react";
import Sidebar from "./components/sidebar";

export default function App() {
  return (
    <Sidebar />
  );
}